var InitiateSimpleDataTable = function() {
    return {
        init: function() {
            try {
                var oTable = $('.simpledatatable').dataTable({
                    "sDom": "Tflt<'row DTTTFooter'<'col-sm-6'i><'col-sm-6'p>>",
                    "aLengthMenu": [
                        [10, 15, 20, 50, 100, -1],
                        [10, 15, 20, 50, 100, "All"]
                    ],
                    "iDisplayLength": 20,
                    "oTableTools": {
                        "aButtons": [
                            "copy",
                            "print"
                        ],
                        "sSwfPath": `${baseURL}public/assets/swf/copy_csv_xls_pdf.swf`
                    },
                    "language": {
                        "search": "",
                        "sLengthMenu": "_MENU_",
                        "oPaginate": {
                            "sPrevious": "Prev",
                            "sNext": "Next"
                        }
                    },
                    "aaSorting": []
                });

                //Check All Functionality
                $('.simpledatatable thead th input[type=checkbox]').change(function() {
                    var set = $(".simpledatatable tbody tr input[type=checkbox]");
                    var checked = $(this).is(":checked");
                    $(set).each(function() {
                        if (checked) {
                            $(this).prop("checked", true);
                            $(this).parents('tr').addClass("active");
                        } else {
                            $(this).prop("checked", false);
                            $(this).parents('tr').removeClass("active");
                        }
                    });

                });
                $('.simpledatatable tbody tr input[type=checkbox]').change(function() {
                    $(this).parents('tr').toggleClass("active");
                });
            } catch(error) {}
        }

    };
}();
InitiateSimpleDataTable.init();