$(`div[class="login-icon"] span`).on("click", function() {
	$(`div[class="login-icon"]`).addClass("fadeOut hidden");
	$(`form[class~="login-form"]`)
		.removeClass("hidden")
		.addClass("animated fadeInDown");
});

var Notify = (message, theme = "danger", icon = 'fa-bell-o') => {
    toastr.options.positionClass = 'toast-top-right';
    toastr.options.extendedTimeOut = 0;
    toastr.options.timeOut = 5000;
    toastr.options.closeButton = true;
    toastr.options.iconClass = icon + ' toast-' + theme;
    toastr['custom'](message);
}

$(`div[class~="lock-container"] i[class~="glyphicon-log-in"]`).on("click", function() {
	let password = $(`div[class~="lock-container"] input[name="password"]`).val();
	if(password.length < 2) {
		Notify('Sorry! The password must not be empty', 'danger');
		$(`div[class~="lock-container"] input[name="password"]`).focus();
	} else {
		$(`form[id="authForm"]`).trigger("submit");
	}
});

$(`form[id="authForm"]`).on("submit", function(evt) {
	evt.preventDefault();
	let formData = $(this).serialize(),
		formURL = $(this).attr("action");
	$(`div[class="ajaxresult"]`).html(`
		<div class="alert alert-info">Validating Credentials... <i class="fa fa-spinner fa-spin"></i></div>
	`);
	$(`form[id="authForm"] *`).attr("disabled", true);

	$.post(`${formURL}`, formData).then((response) => {
		$(`div[class="ajaxresult"]`).html(``);
		if(response.code == 200) {
			$(`div[class="ajaxresult"]`).html(`
				<div class="alert alert-success">Login Successful. Redirecting <i class="fa fa-spinner fa-spin"></i></div>
			`);
			setTimeout(() => {
				window.location.href = `${baseURL}dashboard`;
			}, 2000);
			if($(`div[class~="lock-container"] i[class~="glyphicon-log-in"]`).length) {
				Notify(response.data.result, 'success');
			}
		} else {
			Notify(response.data.result, 'danger');
			$(`form[id="authForm"] *`).attr("disabled", false);
			$(`form[id="authForm"] input[name="password"]`).val("");
		}
	});
});