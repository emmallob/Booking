$.pageoverlay = $(`div[class="pageoverlay"]`);
$.formoverlay = $(`div[class="formoverlay"]`);
$.submitoption = "submit";
$.interval = 90000;

var responseCode = (code) => {
    return code == 200 ? "success" : "danger";
}

var Notify = (message, theme = "danger", icon = 'fa-bell-o') => {
    toastr.options.positionClass = 'toast-top-right';
    toastr.options.extendedTimeOut = 0;
    toastr.options.timeOut = 5000;
    toastr.options.closeButton = true;
    toastr.options.iconClass = icon + ' toast-' + theme;
    toastr['custom'](message);
}

var _link_click_stopper = (element) => {
    $("a", element).on("click", (event) => {
        if ($(event.currentTarget).hasClass('modal-trigger') ||
            $(event.currentTarget).hasClass('btn-export') ||
            $(event.currentTarget).hasClass('export-btn') ||
            $(event.currentTarget).attr('target') === "_blank" ||
            $(event.currentTarget).attr('role') === "option" ||
            $(event.currentTarget).hasClass('anchor')) {
            return
        }
        let target = event.currentTarget.href
        if (target === "" || target === undefined ||
            target.substr(target.length - 1) === '#' ||
            target.indexOf('#') >= 0) {
            return;
        }
        $(`div[class="pageoverlay"]`).css({"display": "flex"});
    });
}

var _html_entities = (str) => {
    return String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

var _inactivity = () => {
    $.post(`${baseURL}api/auth/_inactivity`).then((response) => {
        if(response.data.additional !== undefined) {
           setTimeout(() => {
                window.location.href = response.data.additional.href;
            }, 2000); 
        }
    });
    setTimeout(() => { _inactivity() }, $.interval);
}

var _logout = () => {
    $.post(`${baseURL}api/auth/_logout`).then((response) => {
        Notify(response.data.result, responseCode(response.code));
        if(response.code == 200) {
            setTimeout(() => {
                window.location.href = `${baseURL}auth/login`;
            }, 2000);
        }
    })
}

var _module_selector = (module_id) => {
    $.post(`${baseURL}api/auth/validate_module`, {module_id}).then((response) => {
        Notify(response.data.result, responseCode(response.code));
        if(response.code == 200) {
            setTimeout(() => {
                window.location.href = `${baseURL}dashboard`;
            }, 2000);
        }
    });
}

var _request_to_join = (company_id) => {
    swal({
        title: "Join Company",
        text: `Are you sure you want to proceed to request to be added to this Company?`,
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((proceed) => {
        if(proceed) {
            $.post(`${baseURL}api/companies/join`, {company_id}).then((response) => {
                Notify(response.data.result, responseCode(response.code));
                if(response.code == 200) {
                    setTimeout(() => {
                        window.location.href = `${currentURL}`;
                    }, 2000);
                }
            });
        }
    });
}

var _init_summary = () => {
    if($(`span[data-summary_item]`).length) {
        $.get(`${baseURL}api/analytics/summary`).then((response) => {
            if(response.code == 200) {
                if(response.data.result.count !== undefined) {
                    $.each(response.data.result.count, function(key, value) {
                        $(`span[data-summary_item="${key}['value']"]`).html(value);
                        $(`span[data-summary_item="${key}['percentage']"]`).html(`100%`);
                    });
                }
            }
        });
    }
}

var _init_plugins = () => {
    if($(`form[id="appForm"]`).length) {
        $(`form[id="appForm"]`).bootstrapValidator();
    }

    if($(`input[class~="datepicker"]`).length) {
        $(`input[class~="datepicker"]`).datepicker();
    }

    if ($(`select[class~="selectpicker"]`).length > 0) {
        $(`select[class~="selectpicker"]`).each((index, el) => {
            let select = $(el),
                title = select.attr("data-select-title"),
                itemText = select.attr("data-itemtext"),
                itemsText = select.attr("data-itemstext"),
                width = select.attr("data-select-width"),
                maxOptions = select.attr("data-select-max");

            select.select2();
        });
    }

    if($(`div[data-library="summernote"]`).length) {
        $(`div[data-library="summernote"]`).summernote({ height: 300 });
        $(`div[class="note-dialog"] div[class="modal-body"] p, 
            button[data-event="fullscreen"], 
            div[class~="note-insert"]`).remove();
    }

    $(`select[name="company_id"]`).on("change", function() {
        let selected = $(`select[name="company_id"] > option:selected`).data();
        if(selected.name == undefined) {
            $(`div[class~="company-details"]`).html(``);
            return false;    
        }
        $(`div[class~="company-details"]`).html(`
            <div class="company-details text-black">           
                <div><strong>Name: </strong>${selected.name}</div>
                <div><strong>Reg. Number:</strong>${selected.business_id}</div>
                <div><strong>Website:</strong> ${selected.website}</div>
            </div>
        `);
    });

    $(`div[class~="trix-button-row"] span[class~="trix-button-group--file-tools"], 
        div[class~="trix-button-row"] span[class~="trix-button-group-spacer"]`).remove();
}

var _delete_record = (record, record_id) => {
    swal({
        title: "Delete Record",
        text: `Are you sure you want to proceed to delete this record? This action cannot be reversed once confirmed.`,
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((proceed) => {
        if(proceed) {
            $.post(`${baseURL}api/app/delete`, {record, record_id}).then((response) => {
                Notify(response.data.result, responseCode(response.code));
                if(response.code == 200) {
                    setTimeout(() => {
                        window.location.href = `${currentURL}`;
                    }, 2000);
                }
            });
        }
    });
}

var _form_handler = () => {

    $(`form[id="appForm"] button[type="submit"]`).on("click", function() {
        if($(this).attr("data-type") !== undefined) {
            $.submitoption = $(this).attr("data-type");
        }
    });

    $(`form[id="appForm"]`).on("submit", function(evt) {

        evt.preventDefault();

        setTimeout(() => {

            let theButton = $(this);
            let formAction = $(`form[id="appForm"]`).attr("action"),
                formButton = $(`form[id="appForm"] button[type="submit"]`);

            if($(`div[class~="has-feedback"]`).hasClass("has-error")) {
                return false;
            }

            let myForm = document.getElementById("appForm");
            let theFormData = new FormData(myForm);

            $.each($(`div[data-library="summernote"]`), function() {
                let smnote_name = $(this).attr("name");
                theFormData.delete(`${smnote_name}`);
                let smnote_content = $(`form[id="appForm"] div[class="note-editable"]`).html();
                theFormData.append(`${smnote_name}`, _html_entities(smnote_content));
            });

            $.each($(`trix-editor`), function() {
                let trix_name = $(this).attr("name");
                theFormData.delete(`${trix_name}`);
                let trix_content = $(this).html();
                theFormData.append(`${trix_name}`, _html_entities(trix_content));
            });
            
            let msg = $.submitoption == 'submit' ? `Are you sure you want to save this form?` :
                    `Are you sure you want to save this form in Draft Mode?`;
            
            theFormData.append('the_button', $.submitoption);

            swal({
                title: "Save Form",
                text: msg,
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((proceed) => {
                if (proceed) {
                    formButton.prop("disabled", true);
                    $.formoverlay.show();
                    $.ajax({
                        url: `${formAction}`,
                        data: theFormData,
                        contentType: false,
                        cache: false,
                        type: `POST`,
                        processData: false,
                        success: function(response) {
                            if (response.code == 200) {
                                swal({
                                    text: response.data.result,
                                    icon: "success",
                                });
                                if (response.data.additional) {
                                    if (response.data.additional.href !== undefined) {
                                        setTimeout(() => {
                                            window.location.href = response.data.additional.href;
                                        }, 1500);
                                    }
                                }
                            } else {
                                if (response.data.result !== undefined) {
                                    swal({
                                        position: 'top',
                                        text: response.data.result,
                                        icon: "error",
                                    });
                                } else {
                                    swal({
                                        position: 'top',
                                        text: "Sorry! Error processing request.",
                                        icon: "error",
                                    });
                                }
                            }
                        },
                        complete: function() {
                            $.formoverlay.hide();
                            formButton.prop("disabled", false);
                        },
                        error: function() {
                            $.formoverlay.hide();
                            formButton.prop("disabled", false);
                            swal({
                                position: 'top',
                                text: "Sorry! Error processing request.",
                                icon: "error",
                            });
                        }
                    });
                } else {
                    formButton.prop("disabled", false);
                }
            });

        }, 1000);

    });

}

_link_click_stopper($(document.body));
_inactivity();
_init_plugins();
_form_handler();
_init_summary();