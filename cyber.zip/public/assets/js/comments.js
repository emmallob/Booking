var _comments_container = $(`div[id="comments-container"]`);

var _comment_display = (rv) => {
    return `
    <div class="col-md-12 mb-2 p-1 grid-margin" id="comment-listing" data-reply-container="${rv.item_id}">
        <div class="pb-2 mb-2 replies-item">
            <div class="card-header pb-0">
                <div class="col-lg-12 p-0">
                    <div class="d-flex justify-content-start">
                        <div>
                            <img width="50px" class="img-xs rounded-circle" src="${baseURL}${rv.replied_by.image}" alt="">
                        </div>
                        <div class="ml-2">
                            <p class="cursor mb-0" data-id="${rv.user_id}">
                                <span class="font-bold">${rv.replied_by.fullname.toUpperCase()}</span>
                                <span class="ml-2 text-primary" data-username="@${rv.replied_by.username}">@${rv.replied_by.username}</span>
                            </p>
                            <p title="${rv.modified_date}" class="tx-11 mb-0 replies-timestamp text-muted">${rv.time_ago}</p>
                        </div>
                    </div>
                    ${rv.delete_button}
                </div>
            </div>
            <div class="card-body pt-2 pb-0">
                <div class="tx-14">${rv.message}</div>
            </div>
        </div>
    </div>`;
}

var _leave_comment = (resource, item_id) => {

    let content = $(`trix-editor[id="leave_comment_content"]`),
        theLoader = $(`div[class="leave-comment-wrapper"] div[class~="absolute-content-loader"]`);

    let comment = {
        item_id: item_id,
        resource: resource,
        comment: _html_entities(content.html())
    };

    $(`div[class~="formoverlay"]`).css("display", "flex");

    $.post(`${baseURL}api/comments/save`, comment).then((response) => {
        $(`[class~="formoverlay"]`).css("display", "none");
        if (response.code == 200) {
            content.html("");
            $(`div[class="leave-comment-wrapper"] div[class~="file-preview"]`).html("");
            Notify(response.data.result, "success");
            if (response.data.additional.record) {
                $.each(response.data.additional.record, function(ie, iv) {
                    $(`[data-record="${ie}"]`).html(iv);
                });
                let comment = _comment_display(response.data.additional.data);
                if ($(`div[id="comments-container"] div[id="comment-listing"]:first`).length) {
                    $(`div[id="comments-container"] div[id="comment-listing"]:first`).before(comment);
                } else {
                    $(`div[id="comments-container"]`).append(comment);
                }
            }
        } else {
            Notify(response.data.result);
        }
    }).catch(() => {
        $(`div[class~="leave-comment-wrapper"] div[class~="form-content-loader"]`).css("display", "none");
        Notify("Sorry! Error processing request.");
    });
}

var _comments_loader = async(data) => {
    await $.get(`${baseURL}api/comments/list`, data).then((response) => {
        if (response.code == 200) {
            if (response.data.result) {
                let result = response.data.result;
                _comments_container.attr("data-last-reply-id", result.last_reply_id);
                $(`[data-record="comments_count"]`).html(result.comments_count);
                if (result.replies_list) {
                    let html = "",
                        prev_date = "";
                    $.each(result.replies_list, function(_, value) {
                        if (!prev_date || prev_date != value.raw_date) {
                            html += `<div class="message_list_day_divider_label"><button class="message_list_day_divider_label_pill">${value.clean_date}</button></div>`;
                        }
                        html += _comment_display(value);
                        prev_date = value.raw_date;
                    });
                    _comments_container.append(html);
                    $(`button[id="load-more-replies"]`).fadeIn("slow").html("Load more");
                }
                if (!result.replies_list.length) {
                    $(`button[id="load-more-replies"]`).html("No comments available").attr("disabled", true);
                }
                if ((result.last_reply_id == "no_more_record") || (result.first_reply_id == result.last_reply_id)) {
                    $(`button[id="load-more-replies"]`).html("No comments available").attr("disabled", true);
                }
            }
        }
    });
}

if (_comments_container.length) {
    $(`button[id="load-more-replies"]`).html(`Loading comments <i class="fa fa-spin fa-spinner"></i>`);
    let autoload = _comments_container.attr("data-autoload");
    if (autoload === "true") {
        let data = {
            resource_id: _comments_container.attr("data-id"),
            last_reply_id: _comments_container.attr("data-last-reply-id"),
            limit: 10
        };
        _comments_loader(data);
        _comments_container.attr("data-autoload", "false");
    }
}

$(`button[id="load-more-replies"]`).on("click", function() {
    $(`button[id="load-more-replies"]`).html(`Loading comments <i class="fa fa-spin fa-spinner"></i>`);
    let last_comment = _comments_container.attr("data-last-reply-id");

    if (last_comment == "no_more_record") {
        $(`button[id="load-more-replies"]`).html("No comments available").attr("disabled", true);
        return false;
    }
    let data = {
        resource_id: _comments_container.attr("data-id"),
        last_reply_id: last_comment,
        limit: 10
    };
    _comments_loader(data);
});